import logo from './logo.svg';
import './App.css';
import './Send.css';
import emailjs from 'emailjs-com';
import { useNavigate } from "react-router-dom";
import { BrowserRouter as Router, Switch, Route, Link, Routes } from 'react-router-dom';
function sendEmail(e) {
  e.preventDefault();

  // Get the values of the form fields
  const sender_name = e.target.sender_name.value;
  const reciever_mail = e.target.reciever_mail.value;
  const mail = e.target.mail.value;

  // Create an object containing the values for the template variables
  const templateParams = {
    sender_name: sender_name,
    reciever_mail: reciever_mail,
    mail: mail
  };

  // Send the email using the specified service and template
  emailjs.send('service_kxyw1qa', 'template_pmh7lyo', templateParams, '-qFixZjFXrjL0Ymia')
    .then((result) => {
        console.log(result.text);
    }, (error) => {
        console.log(error.text);
    });
}
function Send() {
    const navigate = useNavigate();
  return (
    <div className='h-screen w-screen'>
      <div className='w-full bg-blue-200 p-1'>
      <Link to="/" onClick={()=> navigate("/Home")}>
          <button className='bg-blue-600 hover:bg-white text-white hover:text-black font-bold py-1 px-2 ml-12'>a2zShare</button>
      </Link>
      <Link to="/Send" onClick={()=> navigate("/Send")}>
          <button className='hover:bg-blue-400 text-black hover:text-white font-bold py-1 px-2 ml-12'>Send</button>
      </Link>
      <Link to="/Download" onClick={()=> navigate("/Download")}>
          <button className='hover:bg-blue-400 text-black hover:text-white font-bold py-1 px-2 ml-12'>Download</button>
      </Link>
      <Link to="/Contact" onClick={()=> navigate("/Contact")}>
          <button className='hover:bg-blue-400 text-black hover:text-white font-bold py-1 px-2 ml-12'>Contact Us</button>
      </Link>
      <Link to="/Donate" onClick={()=> navigate("/Donate")}>
          <button className='hover:bg-blue-400 text-black hover:text-white font-bold py-1 px-2 ml-12'>Support Us</button>
      </Link>
      </div>
      <div className='grid grid-cols-2 gap-4 ml-36 mt-8'>

        <div className='mt-44 ml-28'>
        <Link to="/" onClick={()=> navigate("/Home")}>
          <img src={logo} className="App-logo" alt="logo" />
          </Link>
        </div>

        <div className='Contentbox align-middle'>
          <div>
          <p className='text-4xl text-white text-center'>Send File</p>
          </div>
            <form onSubmit={sendEmail}>
            <div className='text-xl mt-8'>
            <input type='text' placeholder='Sender Name' id='sender_name' name='sender_name' className='w-full h-10 border-solid border-2 font-serif border-black rounded'></input>
            </div>
            <div className='text-xl mt-3'>
            <input type='text' placeholder='Reciever E-mail' id='reciever_mail' name='reciever_mail' className='w-full h-10 border-solid font-serif border-2 border-black rounded'></input>
            </div>
            <div className='text-xl mt-3'>
            <textarea name="mail" id='mail' rows={10} cols={45} className='w-full border-solid font-serif border-2 border-black rounded' placeholder='Message' />
            </div>
            <div className='text-xl mt-3'>
            <input type='file' className='w-full h-10 border-solid font-serif border-2 border-black rounded'></input>
            </div>
            <div className='mt-8 ml-10'>
            
            <input type='submit' value='Send' className='bg-white hover:bg-green-800 text-black hover:text-white font-bold py-4 px-8 p-4 text-2xl rounded'></input>
            
            </div>
            </form>
          <div className='ml-56 -mt-16'>
          <Link to="/Share" onClick={()=> navigate("/Share")}>
          <button className='bg-blue-400 hover:bg-green-800 text-black hover:text-white font-bold py-4 px-8 text-2xl rounded ml-8'>Share</button>
          </Link>
          </div>

        </div>
      </div>
  </div>
  );
}

export default Send;